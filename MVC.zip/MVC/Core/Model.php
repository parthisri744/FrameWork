<?php
namespace Core;
use PDO;
use App\Config;

abstract class Model {

    protected static function getDB(){
        static $db=null;
        if($db===null){
            // $host ="localhost";
            // $dbname="parthisri";
            // $username="root";
            // $password ="";
            try {
               // echo "Database :".Config::DB_USER."<pre/>";
           // $db=new PDO("mysql:host=$host;dbname=$dbname;",$username,$password);
           $dns ='mysql:host='.Config::DB_HOST.';dbname='.Config::DB_NAME.';';
           $db = new PDO($dns,Config::DB_USER,Config::DB_PASSWORD);
           $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

           return $db;
            } catch (PDOException $e){
                echo $e->getMessage()."<pre/>";
            }
        }
    }
}