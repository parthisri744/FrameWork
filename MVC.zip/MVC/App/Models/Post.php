<?php
namespace App\Models;

use PDO;

class Post extends \Core\Model {

    public static function getAll(){

        // $host ="localhost";
        // $dbname = "parthisri";
        // $username = "root";
        // $password = "";
        try {
           // $db=new PDO("mysql:host=$host;dbname=$dbname;",$username,$password);
            //echo "Connected Successfully";
            $db = static::getDB(); 

            $stmt = $db->query("SELECT * FROM users ");
            $result =$stmt->fetchAll(PDO::FETCH_ASSOC);
            return $result;

        } catch (PDOException  $e){
            echo $e->getMessage();
        }
    }
}