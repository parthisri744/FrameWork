<?php

namespace App;

/**
 * Application configuration
 *
 * 
 */
class Config
{

    /**
     * Database host
     * 
     */
    const DB_HOST = 'localhost';

    /**
     * Database name
     * 
     */
    const DB_NAME = 'parthisri';

    /**
     * Database user
     * 
     */
    const DB_USER = 'root';

    /**
     * Database password
     * 
     */
    const DB_PASSWORD = '';
    /**
     * 
     * Show or hide Error Message on Screen
     */
    const SHOW_ERRORS =false;
}